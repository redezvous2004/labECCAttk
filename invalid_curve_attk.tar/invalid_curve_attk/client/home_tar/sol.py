#!/usr/bin/python3
import socket
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import sha3_256
import re
from ecdsa import ellipticcurve
from sympy import mod_inverse
from sympy.ntheory.modular import crt
import math
import time
# Đọc tham số từ file curves.txt
params = []

with open("curves.txt") as f:
    content = f.read()

# Tìm tất cả các block Curve
curve_blocks = re.findall(r"b\s*=\s*(\d+)\s*Point G\s*=\s*\((\d+),\s*(\d+)\)\s*Order\s*=\s*(\d+)\s*Factors\s*=\s*\[([0-9,\s]+)\]", content)

for b, x, y, order, factors_str in curve_blocks:
    b = int(b)
    G = (int(x), int(y))
    order = int(order)
    factors = [int(f) for f in factors_str.strip().split(',')]
    params.append((b, G, order, factors))

for i, (b, (x, y), od, subgroups) in enumerate(params):
    print(f"False curve {i+1}: b = {b}, Point G = ({x}, {y}), Order of G = {od}, Subgroups = {subgroups}")

# Tham số đường cong elliptic
a = 34
p = 1021
n = 1030

# Hàm tự triển khai Baby-step Giant-step để giải DLP
def baby_step_giant_step(P, Q, order, p):
    """Giải bài toán DLP: tìm k sao cho Q = kP trên đường cong elliptic"""
    # Kiểm tra trường hợp đặc biệt
    if P.x() is None or P.y() is None:
        return None
    if Q.x() is None or Q.y() is None:
        return 0  # Q là điểm vô cực, k = 0
    
    # Kiểm tra nếu P = Q
    if P.x() == Q.x() and P.y() == Q.y():
        return 1
    
    m = math.ceil(math.sqrt(order))
    
    # Baby-step: Tạo bảng lookup
    baby_steps = {}
    R = ellipticcurve.INFINITY  # Bắt đầu từ điểm vô cực (0*P)
    
    for i in range(m):
        try:
            if R.x() is not None and R.y() is not None:
                baby_steps[(R.x(), R.y())] = i
            elif R == ellipticcurve.INFINITY and Q == ellipticcurve.INFINITY:
                return i
            R = R + P  # Tính iP
        except:
            break
    
    # Giant-step
    try:
        factor = m * P
        Q_temp = Q
        
        for j in range(m):
            try:
                if Q_temp == ellipticcurve.INFINITY:
                    if 0 in baby_steps.values():
                        return j * m
                elif Q_temp.x() is not None and Q_temp.y() is not None:
                    if (Q_temp.x(), Q_temp.y()) in baby_steps:
                        i = baby_steps[(Q_temp.x(), Q_temp.y())]
                        return (i + j * m) % order
                Q_temp = Q_temp - factor
            except:
                continue
    except:
        pass
    
    return None  # Không tìm thấy giải pháp

def get_dlp(b, x, y):
    # Tạo đường cong elliptic với ecdsa
    curve = ellipticcurve.CurveFp(p, a, b)
    Q = ellipticcurve.Point(curve, x, y, n)
    
    with socket.socket() as s:
        s.connect(('172.20.3.2', 9999))
        data = f"POINT:{x},{y}"
        s.send(data.encode())
        response = s.recv(1024).decode().strip()
    
    x_recv, y_recv = map(int, response.split(','))
    try:
        P = ellipticcurve.Point(curve, x_recv, y_recv, n)
        return P, Q
    except Exception as e:
        print(f"Error creating point: {e}")
        return None, None

# Giải bài toán logarit rời rạc trên các nhóm con
def sol_dlp():
    sec = []
    mod = []
    
    for i, (b, (x, y), od, subgroups) in enumerate(params):
        print(f"\nProcessing curve {i+1} with b = {b}:")
        P, Q = get_dlp(b, x, y)
        if P is None or Q is None:
            print(f"Skipping curve {i+1} due to invalid points")
            continue
            
        print(f"P: ({P.x()}, {P.y()}), Q: ({Q.x()}, {Q.y()})")
        
        for subgroup in subgroups:
            print(f"solving size {subgroup}")
            tmp = od // subgroup
            
            try:
                # Tính tmp * P và tmp * Q
                tmp_P = tmp * P
                tmp_Q = tmp * Q
                
                # Xử lý trường hợp điểm vô cực
                if tmp_P == ellipticcurve.INFINITY:
                    print(f"tmp_P is point at infinity for subgroup {subgroup}")
                    # Nếu tmp_P là vô cực, thử với P gốc
                    k = baby_step_giant_step(P, Q, subgroup, p)
                    if k is not None:
                        k = k % subgroup
                        print(f"Using original P, k: {k} mod {subgroup}")
                        sec.append(k)
                        mod.append(subgroup)
                    continue
                    
                if tmp_Q == ellipticcurve.INFINITY:
                    print(f"tmp_Q is point at infinity for subgroup {subgroup}, k = 0")
                    sec.append(0)
                    mod.append(subgroup)
                    continue
                
                # Giải DLP trên nhóm con
                k = baby_step_giant_step(tmp_P, tmp_Q, subgroup, p)
                if k is None:
                    print(f"Failed to solve DLP for subgroup {subgroup}")
                    # Thử phương pháp brute force cho subgroup nhỏ
                    if subgroup <= 100:
                        print(f"Trying brute force for subgroup {subgroup}")
                        k = brute_force_dlp(tmp_P, tmp_Q, subgroup)
                    
                if k is not None:
                    # Đảm bảo k nằm trong khoảng [0, subgroup-1]
                    k = k % subgroup
                    print(f"k: {k} mod {subgroup}")
                    
                    # Verification: kiểm tra k*tmp_P == tmp_Q
                    try:
                        verification = k * tmp_P
                        if verification == tmp_Q:
                            print(f"Passed: {k}*tmp_P == tmp_Q")
                        else:
                            print(f"Failed: {k}*tmp_P != tmp_Q")
                            print(f"Expected: {tmp_Q}")
                            print(f"Got: {verification}")
                            # Thử brute force nếu verification fail
                            if subgroup <= 50:
                                print("Trying brute force due to verification failure...")
                                k_bf = brute_force_dlp(tmp_P, tmp_Q, subgroup)
                                if k_bf is not None:
                                    k = k_bf
                                    print(f"Brute force found: k = {k}")
                    except Exception as ve:
                        print(f"Verification error: {ve}")
                    
                    sec.append(k)
                    mod.append(subgroup)
                else:
                    print(f"Still failed to solve DLP for subgroup {subgroup}")
                    
            except Exception as e:
                print(f"Error processing subgroup {subgroup}: {e}")
                continue
    
    print(f"Collected solutions: {list(zip(sec, mod))}")
    
    # Sử dụng CRT để tìm khóa bí mật
    if sec and mod:
        try:
            # Thử cả hai thứ tự tham số cho CRT
            print("Trying CRT with (mod, sec)...")
            time.sleep(3)
            result = crt(mod, sec)[0]
            
            # Kiểm tra kết quả nào hợp lý hơn
            # Thường secret key sẽ trong khoảng [1, n-1]
            print(f"Result: {result}")
            
            # Trả về kết quả đầu tiên (thứ tự đúng của sympy.crt)
            return result
            
        except Exception as e:
            print(f"CRT error: {e}")
            # Thử manual CRT implementation
            return manual_crt(sec, mod)
    else:
        print("No valid solutions found for CRT")
        return None

# Thêm manual CRT implementation để debug
def manual_crt(remainders, moduli):
    """Manual Chinese Remainder Theorem implementation"""
    try:
        if len(remainders) != len(moduli):
            return None
            
        print(f"Manual CRT: remainders={remainders}, moduli={moduli}")
        
        # Tính tích của tất cả moduli
        M = 1
        for m in moduli:
            M *= m
        print(f"Total M: {M}")
        
        result = 0
        for i in range(len(remainders)):
            Mi = M // moduli[i]
            yi = mod_inverse(Mi, moduli[i])
            result += remainders[i] * Mi * yi
            print(f"Step {i}: remainder={remainders[i]}, modulus={moduli[i]}, Mi={Mi}, yi={yi}")
            
        result = result % M
        print(f"Manual CRT result: {result}")
        return result
        
    except Exception as e:
        print(f"Manual CRT error: {e}")
        return None

# Thêm hàm brute force cho các subgroup nhỏ
def brute_force_dlp(P, Q, order):
    """Brute force DLP cho các subgroup nhỏ"""
    try:
        if P == ellipticcurve.INFINITY:
            return None
        if Q == ellipticcurve.INFINITY:
            return 0
            
        R = ellipticcurve.INFINITY
        for k in range(order):
            if R == Q:
                return k
            R = R + P
        return None
    except:
        return None

# Menu chính
while True:
    option = input("""Option:
1. Send fault points to server
2. Request a ciphertext with your message
3. Exit
Your choice: """)
    if option == '1':
        d = sol_dlp()
        if d is not None:
            print(f"Found secret!!! Please view secret key in 'secretkey.txt'")
            with open("secretkey.txt", "w") as f:
                f.write(str(d))
        else:
            print("Failed to find secret key")
    elif option == '2':
        message = input("Type message: ")
        with socket.socket() as s:
            s.connect(('172.20.3.2', 9999))
            mess = f"MSG:{message}"
            s.send(mess.encode())
            response = s.recv(1024)
            with open("ciphertext.enc", "wb") as f:
                f.write(response)
            print(f"Ciphertext saved to 'ciphertext.enc'")
    else:
        message = "Client has closed connection"
        with socket.socket() as s:
            s.connect(('172.20.3.2', 9999))
            mess = f"CLS:{message}"
            s.send(mess.encode())
        break
